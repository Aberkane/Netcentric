void control_robot(int command);





