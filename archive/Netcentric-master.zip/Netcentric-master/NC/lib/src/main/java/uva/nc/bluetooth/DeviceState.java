package uva.nc.bluetooth;

public enum DeviceState {
    Connecting,
    Disconnected,
    Connected,
    Unknown
}
